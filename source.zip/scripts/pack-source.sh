#!/usr/bin/env bash
# Packs the full WebQuid browser-node source tree into public/webquid-source.zip
# for downstream packagers; the Terminal homepage intentionally has no source-
# download control. Runs automatically on EVERY build (scripts/copy-public.mjs
# execs this before copying public/ -> dist/), so the archive cannot lag behind
# the shipped code.
set -euo pipefail
cd "$(dirname "$0")/.."

OUT="public/webquid-source.zip"
# zip replaces archives via temp-file + rename(2), which some filesystems
# (network/FUSE mounts) reject. Build in /tmp, then plain-copy into place.
TMP="$(mktemp /tmp/webquid-source.XXXXXX.zip)"
rm -f "$TMP" # zip cannot replace an existing archive on every filesystem
MARKER_DIR="$(mktemp -d /tmp/webquid-marker.XXXXXX)"
MARKER="$MARKER_DIR/BUILD-INFO.txt" # fixed basename: zip -j keeps it at the archive root
trap 'rm -f "$TMP"; rm -rf "$MARKER_DIR"' EXIT

# Build marker baked into every snapshot: proves WHICH build the zip came
# from. Regenerated on every run, so two builds can never ship the same zip.
VERSION="$(node -p "require('./package.json').version" 2>/dev/null || echo "0.0.0")"
{
  echo "WEBQUID SOURCE SNAPSHOT"
  echo "built_at_utc: $(date -u +%Y-%m-%dT%H:%M:%SZ)"
  echo "version: ${VERSION}"
  echo "chain: webquid-mainnet-2"
} > "$MARKER"

# .github rides along: the Pages deploy workflow must travel WITH the
# sources, or a fresh repo receiving this zip has no workflow to unpack it.
zip -r "$TMP" \
  src contracts public scripts .github \
  index.html network.config.ts \
  package.json package-lock.json .nvmrc .node-version \
  tsconfig.json tsconfig.app.json tsconfig.node.json \
  vite.config.ts vitest.config.ts \
  tailwind.config.js components.json eslint.config.js \
  README.md LICENSE TRADEMARK.md \
  -x "public/*.zip" \
  -x "src/node-dist/*" \
  -x "node_modules/*" \
  -x "dist/*" \
  -x ".git/*" \
  > /dev/null

# Marker sits at the archive root, next to README.md.
zip -j "$TMP" "$MARKER" > /dev/null

rm -f "$OUT"
cp "$TMP" "$OUT"

echo "packed $(du -h "$OUT" | cut -f1) → $OUT"
