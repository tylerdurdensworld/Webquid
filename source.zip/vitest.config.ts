import { defineConfig } from "vitest/config";
import path from "path";

const templateRoot = path.resolve(import.meta.dirname);

export default defineConfig({
  root: templateRoot,
  resolve: {
    alias: {
      "@": path.resolve(templateRoot, "src"),
      "@contracts": path.resolve(templateRoot, "contracts"),
    },
  },
  test: {
    environment: "node",
    include: ["src/**/*.test.ts", "contracts/**/*.test.ts"],
    // Node 22+ exposes experimental Web Storage globals. Tests install their
    // own explicit storage stubs; disabling the built-ins keeps unavailable-
    // storage cases deterministic and avoids Node 26's localStorage warning.
    execArgv: ["--no-experimental-webstorage"],
  },
});
