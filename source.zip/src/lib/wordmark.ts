import { computeLogoFillPlan } from "@/lib/logo-fill";

/* -- ASCII logo ----------------------------------------------------------- */
export const ASCII_LOGO = String.raw`
██╗    ██╗ ███████╗ ██████╗   ██████╗  ██╗   ██╗     ██████╗ 
██║    ██║ ██╔════╝ ██╔══██╗ ██╔═══██╗ ██║   ██║ ██║ ██╔══██╗
██║ █╗ ██║ █████╗   ██████╔╝ ██║   ██║ ██║   ██║ ██║ ██║  ██║
██║███╗██║ ██╔══╝   ██╔══██╗ ██║▄▄ ██║ ██║   ██║ ██║ ██║  ██║
╚███╔███╔╝ ███████╗ ██████╔╝ ╚██████╔╝ ╚██████╔╝ ██║ ██████╔╝
 ╚══╝╚══╝  ╚══════╝ ╚═════╝   ╚══▀▀═╝   ╚═════╝  ╚═╝ ╚═════╝ 
`;

/**
 * Fit the 61-column wordmark to its container, deterministically: set the
 * cap size, MEASURE the real rendered width, then shrink linearly until it
 * fits. Viewport-unit clamps fail here twice over - vw ignores container
 * padding, and Android text scaling inflates font-size without inflating
 * vw. Measuring the rendered result converges in one pass (monospace width
 * is linear in font-size) and is immune to both.
 */
// cap 18.3678 = 12 * 1.10^3 * 1.15: the WebQuid rebrand bumped the wordmark
// a further 15% on top of the original 33% enlargement wherever it fits
// (desktop/tablet). Narrow phones stay at the width-limited fitted size.
/* -- The wordmark coin ------------------------------------------------------
 * The I of WEBQUID wears a coin for its tittle (reference mockup), shipped
 * at 0.8x the mockup's coin size. All geometry is pinned to the character
 * grid (ch/em), so useWordmarkFit's font scaling keeps the coin glued to
 * the I glyph at every size and DPR. Mockup measurements (841x195 render):
 * coin diameter 5.13ch, centered on the I glyph (columns 49-51 -> 50.5ch),
 * center 1.07ch above the first glyph row -> shipped at 4.1ch (0.8x), same
 * center. Vertical anchor: the <pre> opens with one empty line (the
 * template literal's leading newline) at line-height 1.12, which puts the
 * first glyph row's ink ~1.18em below the pre's top edge; coin center =
 * 1.18 - 0.64 = 0.54em.
 */
export const COIN_GEOM = {
  // centered on the I stem's SOLID body (columns 49-50), then nudged a hair
  // right and down on review: 50.3ch keeps the coin on the stem body while
  // visually centering it over the glyph's ink mass (the shadow column at
  // 51 pulls the eye right), and 0.62em seats it a touch closer to the
  // letter tops so it reads perched, not floating
  centerColCh: 50.3,
  // 3.49ch = the mockup's 5.13ch at 0.8x, then a further 0.85x on request
  sizeEm: 2.09,
  centerYEm: 0.62, // coin center below the pre's top edge
} as const;

// The coin's light threshold in the letter-by-letter supply fill: the
// number of ink characters in every letter strictly LEFT of the coin's own
// glyph (W+E+B+Q+U), so the coin lights up exactly when the fill reaches
// the I it rides on. Derived from the logo string by lib/logo-fill (never
// hardcoded); SupplyLogo reuses the same module-level plan for its runs.
export const LOGO_FILL_PLAN = computeLogoFillPlan(
  ASCII_LOGO.trimEnd(),
  Math.floor(COIN_GEOM.centerColCh), // a column inside the coin's glyph
);
export const COIN_INK_AT = LOGO_FILL_PLAN.coinAt;
