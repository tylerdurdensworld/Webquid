import { describe, expect, it } from "vitest";
import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";

const SOURCE = readFileSync(fileURLToPath(new URL("./Transfers.tsx", import.meta.url)), "utf8");

function block(start: string, end: string): string {
  const from = SOURCE.indexOf(start);
  const to = SOURCE.indexOf(end, from + start.length);
  expect(from, `missing source block: ${start}`).toBeGreaterThanOrEqual(0);
  expect(to, `unterminated source block: ${start}`).toBeGreaterThan(from);
  return SOURCE.slice(from, to);
}

describe("Send -> recorded receipt integration contract", () => {
  it("uses the exact signed mutation variables after node.sendTx resolves", () => {
    const success = block("onSuccess:", "onError:");
    expect(success).toContain("onSuccess: ({ txid }, signed)");
    expect(success).toContain("trackPendingTx(txid, signed.amount)");
    expect(success).toContain('notify(\n        "transfer_recorded"');
    expect(success).toContain("recipient: signed.to");
    expect(success).toContain("amount: signed.amount");
    expect(success).toContain("fee: signed.fee");
    expect(success).toContain("txid,");
    expect(success).toContain("peerless,");
    expect(SOURCE).not.toContain("unsignedAmountRef");
  });

  it("never creates a recorded receipt on the mutation error path", () => {
    const failure = block("onError:", "function broadcast()");
    expect(failure).toContain('notify("error"');
    expect(failure).not.toContain("transfer_recorded");
    expect(failure).not.toContain("buildRecordedTransferMessage");
    expect(failure).not.toContain("trackPendingTx");
  });

  it("keeps admission distinct from confirmation and emits no duplicate sent sound", () => {
    expect(SOURCE).toContain("mutationFn: node.sendTx");
    expect(SOURCE).toContain("It is NOT block inclusion or final confirmation");
    expect(SOURCE).not.toContain('soundEngine.feedback("transaction_sent")');
    expect(SOURCE).toContain('soundEngine.feedback("send_press")');
  });
});
