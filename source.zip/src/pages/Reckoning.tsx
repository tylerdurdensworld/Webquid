/**
 * THE RECKONING - the wallet ledger. Every account this chain remembers,
 * ranked richest-first, with the context that makes a balance readable:
 * share of supply, transfers sent, blocks mined.
 *
 * The Dashboard links here with target="_blank", so this page usually opens
 * in a fresh tab and boots its own node over the same local chain. The read
 * itself is one storage scan per poll (see node/ledger.ts) - slow interval,
 * capped rows, no per-address lookups: the page can stay open forever.
 */
import { useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useNode } from "@/providers/node-context";
import { useWallet } from "@/hooks/useWallet";
import { Cursor, Divider, Panel, Stat } from "@/components/term/ui";
import { fmtCoins, fmtInt, shortAddr } from "@/lib/format";
import { fmtSharePct, LEDGER_ROW_CAP } from "@/node/ledger";

const POLL_MS = 8_000;

export default function Reckoning() {
  const node = useNode();
  const { wallet } = useWallet();
  const [filter, setFilter] = useState("");
  const ledger = useQuery({
    queryKey: ["reckoning", "ledger"],
    queryFn: () => node.ledger(),
    refetchInterval: POLL_MS,
  });
  const view = ledger.data;

  const rows = useMemo(() => {
    const all = view?.rows ?? [];
    const q = filter.trim().toLowerCase();
    if (!q) return all;
    return all.filter((r) => r.address.toLowerCase().includes(q));
  }, [view, filter]);

  return (
    <div className="mx-auto max-w-5xl space-y-4 pb-6">
      <header className="border border-neutral-700 px-4 py-6 text-center">
        <p className="text-[10px] uppercase tracking-[0.4em] text-neutral-500">
          The Wallet Ledger - webquid-mainnet-2
        </p>
        <h1 className="font-term glow mt-3 text-3xl leading-tight sm:text-4xl">
          THE RECKONING
        </h1>
        <p className="mt-3 text-xs text-neutral-400">
          every wallet the chain remembers - ranked by balance
        </p>
        <p className="mt-1 text-[11px] text-neutral-600">
          read locally from this node's own storage - nothing leaves the browser
        </p>
      </header>

      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <Stat
          label="Holders"
          value={view ? fmtInt(view.holders) : "-"}
          sub="wallets with a balance"
        />
        <Stat
          label="Total Supply"
          value={view ? fmtCoins(view.totalSupply) : "-"}
          sub="WQD in existence"
        />
        <Stat
          label="Top 10 Hold"
          value={view ? fmtSharePct(view.topTenShare) : "-"}
          sub="of all WQD"
        />
        <Stat
          label="Addresses Tracked"
          value={view ? fmtInt(view.holders + view.emptyAccounts) : "-"}
          sub={view ? `${fmtInt(view.emptyAccounts)} back to zero` : ""}
        />
      </div>

      <Panel
        title={`Wallet Ledger (top ${LEDGER_ROW_CAP})`}
        right={
          <input
            value={filter}
            onChange={(e) => setFilter(e.target.value)}
            placeholder="filter by address..."
            data-testid="reckoning-filter"
            className="w-44 border border-neutral-700 bg-black px-2 py-0.5 text-[11px] normal-case tracking-normal text-neutral-200 placeholder:text-neutral-600 focus:border-neutral-400 focus:outline-none"
          />
        }
        bodyClassName="p-0 overflow-x-auto"
      >
        <table
          className="term-table w-full text-xs min-[640px]:min-w-[640px]"
          data-testid="reckoning-table"
        >
          <thead>
            <tr>
              <th className="w-[56px]">Rank</th>
              <th>Address</th>
              <th className="text-right">Balance (WQD)</th>
              <th className="hidden text-right sm:table-cell">Share</th>
              <th className="hidden text-right md:table-cell">Sent</th>
              <th className="hidden text-right md:table-cell">Mined</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((r) => (
              <tr key={r.address} data-testid="reckoning-row">
                <td className="text-neutral-500" data-testid="reckoning-rank">
                  #{fmtInt(r.rank)}
                </td>
                <td className="text-neutral-300" title={r.address}>
                  <span data-testid="reckoning-address">{shortAddr(r.address, 12, 8)}</span>
                  {wallet && r.address === wallet.address && (
                    <span
                      className="ml-2 border border-neutral-500 px-1 text-[10px] text-neutral-100"
                      data-testid="reckoning-you"
                    >
                      YOU
                    </span>
                  )}
                </td>
                <td
                  className="text-right text-neutral-100"
                  data-testid="reckoning-balance"
                  title={`${fmtCoins(r.balance)} WQD`}
                >
                  {fmtCoins(r.balance)}
                </td>
                <td className="hidden text-right text-neutral-400 sm:table-cell">
                  {fmtSharePct(r.share)}
                </td>
                <td className="hidden text-right text-neutral-500 md:table-cell">
                  {fmtInt(r.sent)}
                </td>
                <td className="hidden text-right text-neutral-500 md:table-cell">
                  {fmtInt(r.blocksMined)}
                </td>
              </tr>
            ))}
            {view && rows.length === 0 && (
              <tr>
                <td colSpan={6} className="py-4 text-center text-neutral-600">
                  {view.holders === 0
                    ? "NO BALANCES YET - mine a block and this page wakes up"
                    : "no ranked wallet matches that filter"}
                  <Cursor />
                </td>
              </tr>
            )}
            {!view && (
              <tr>
                <td colSpan={6} className="py-4 text-center text-neutral-600">
                  READING THE LEDGER<Cursor />
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </Panel>

      <Divider label="fine print" />
      <p className="pb-2 text-center text-[10px] text-neutral-700">
        balances are confirmed-only and ranked richest-first; empty addresses are
        remembered but not ranked
        {view?.capped ? ` - showing the top ${LEDGER_ROW_CAP} of ${fmtInt(view.holders)} holders` : ""}
        {" - "}refreshed every {POLL_MS / 1000}s, paused while the tab sleeps
      </p>
    </div>
  );
}
