import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";

// The Terminal page is the homepage. Its source-download control was removed
// deliberately; keep the UI free of that entry point without removing the
// independently generated open-source archive used by downstream packagers.
const terminalSource = readFileSync(new URL("./Terminal.tsx", import.meta.url), "utf8");

describe("homepage source-download contract", () => {
  it("does not render a source-download link or label", () => {
    expect(terminalSource).not.toContain('href="./webquid-source.zip"');
    expect(terminalSource).not.toMatch(/DOWNLOAD\s+(?:FULL\s+)?SOURCE/i);
  });

  it("does not point chain-portability copy at the removed control", () => {
    expect(terminalSource).not.toContain("source zip above");
    expect(terminalSource).toContain("exported chain file lets any compatible WebQuid node");
  });
});
