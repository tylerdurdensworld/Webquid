/**
 * THE RECKONING - the wallet ledger behind the Dashboard link.
 *
 * One ranked answer to "who holds what": every account the chain remembers,
 * sorted richest-first, with the context that makes a raw balance readable
 * (share of supply, transfers sent, blocks mined). This module is the pure
 * core: given the account table and the total supply it computes the whole
 * view, so the ranking rules are unit-tested without booting a node. The
 * async storage read lives in chain.ts (getLedger).
 *
 * Cost discipline ("don't strain the system"): the read is ONE scan of the
 * balances store - the same scan boot recovery already runs - plus an
 * in-memory sort capped at LEDGER_ROW_CAP rows. No per-address lookups, no
 * mempool joins, no history walks.
 */
import type { AccountRow } from "./storage";

/**
 * Rows rendered per snapshot. 250 ranks fit on one screen of scrolling and
 * keep the sort/render cost flat no matter how large the account table
 * grows; when holders exceed the cap the view says so (`capped`) instead of
 * silently truncating.
 */
export const LEDGER_ROW_CAP = 250;

export interface LedgerRow {
  /** 1-based position in the richest-first order. */
  rank: number;
  address: string;
  /** Confirmed balance, base units. */
  balance: number;
  /** Fraction of total supply, 0..1 (0 when supply is 0). */
  share: number;
  /** Confirmed transfers sent - the account nonce IS this count. */
  sent: number;
  blocksMined: number;
}

export interface LedgerView {
  rows: LedgerRow[];
  /** Accounts holding a balance right now (the ranked population). */
  holders: number;
  /** Accounts the chain remembers whose balance is back to zero. */
  emptyAccounts: number;
  /** Base units in existence (the denominator of every share). */
  totalSupply: number;
  /** Combined 0..1 share of the ten richest holders, computed BEFORE the cap. */
  topTenShare: number;
  /** True when holders exceed the row cap - the table is a top-N window. */
  capped: boolean;
}

export function buildLedger(
  accounts: readonly AccountRow[],
  totalSupply: number,
  cap: number = LEDGER_ROW_CAP,
): LedgerView {
  const withBalance = accounts.filter((a) => a.balance > 0);
  // Richest first; exact balance ties fall back to the address so every node
  // renders the same order for the same chain state.
  const ranked = [...withBalance].sort(
    (a, b) =>
      b.balance - a.balance ||
      (a.address < b.address ? -1 : a.address > b.address ? 1 : 0),
  );
  const limit = Math.max(0, Math.min(cap, ranked.length));
  const rows: LedgerRow[] = new Array(limit);
  for (let i = 0; i < limit; i++) {
    const a = ranked[i];
    rows[i] = {
      rank: i + 1,
      address: a.address,
      balance: a.balance,
      share: totalSupply > 0 ? a.balance / totalSupply : 0,
      sent: a.nonce,
      blocksMined: a.blocksMined,
    };
  }
  const topTen = ranked
    .slice(0, 10)
    .reduce((sum, a) => sum + a.balance, 0);
  return {
    rows,
    holders: ranked.length,
    emptyAccounts: accounts.length - ranked.length,
    totalSupply,
    topTenShare: totalSupply > 0 ? topTen / totalSupply : 0,
    capped: ranked.length > limit,
  };
}

/**
 * Share cell text. Dust holders deserve honesty, not "0.00%": below one
 * hundredth of a percent the cell reads "<0.01%".
 */
export function fmtSharePct(share: number): string {
  const pct = share * 100;
  if (!(pct > 0)) return "0%";
  if (pct < 0.01) return "<0.01%";
  return `${pct.toFixed(2)}%`;
}
