/**
 * Ledger tests - THE RECKONING's ranking rules, plus the real read path
 * through chain storage.
 *
 * The pure builder (buildLedger) owns every ranking decision: richest
 * first, deterministic ties, the row cap, share math against the supply.
 * The integration section boots a fresh chain on MemoryStorage and writes
 * account rows directly (the read model does not care HOW rows got there),
 * proving getLedger's storage scan wires the real table into the builder.
 */
import { describe, expect, it, vi } from "vitest";
import { buildLedger, fmtSharePct, LEDGER_ROW_CAP } from "./ledger";
import { MemoryStorage, type AccountRow } from "./storage";

function acc(address: string, balance: number, nonce = 0, blocksMined = 0): AccountRow {
  return { address, balance, nonce, blocksMined };
}

/** Deterministic fake addresses - format-valid shape, hex body. */
function addr(n: number): string {
  return `wqd1${n.toString(16).padStart(48, "0")}`;
}

describe("buildLedger - ranking", () => {
  it("ranks richest first with 1-based ranks and per-row fields", () => {
    const view = buildLedger(
      [acc(addr(3), 300), acc(addr(1), 100), acc(addr(2), 200, 5, 2)],
      600,
    );
    expect(view.rows.map((r) => r.address)).toEqual([addr(3), addr(2), addr(1)]);
    expect(view.rows.map((r) => r.rank)).toEqual([1, 2, 3]);
    expect(view.rows[1].sent).toBe(5);
    expect(view.rows[1].blocksMined).toBe(2);
    expect(view.rows[0].share).toBeCloseTo(0.5, 10);
    expect(view.rows[2].share).toBeCloseTo(1 / 6, 10);
  });

  it("breaks exact balance ties by address, identically on every node", () => {
    const a = buildLedger([acc(addr(9), 50), acc(addr(4), 50)], 100);
    const b = buildLedger([acc(addr(4), 50), acc(addr(9), 50)], 100);
    expect(a.rows.map((r) => r.address)).toEqual([addr(4), addr(9)]);
    expect(b.rows.map((r) => r.address)).toEqual(a.rows.map((r) => r.address));
  });

  it("excludes empty accounts from the ranking but counts them", () => {
    const view = buildLedger([acc(addr(1), 100), acc(addr(2), 0), acc(addr(3), 0)], 100);
    expect(view.rows).toHaveLength(1);
    expect(view.holders).toBe(1);
    expect(view.emptyAccounts).toBe(2);
  });

  it("share is 0 when the supply denominator is 0", () => {
    const view = buildLedger([acc(addr(1), 100)], 0);
    expect(view.rows[0].share).toBe(0);
    expect(view.topTenShare).toBe(0);
  });
});

describe("buildLedger - the cap", () => {
  it("slices rows at the cap and reports capped, keeping holders honest", () => {
    const accounts = Array.from({ length: 5 }, (_, i) => acc(addr(i), 100 - i));
    const view = buildLedger(accounts, 500, 3);
    expect(view.rows).toHaveLength(3);
    expect(view.rows.map((r) => r.rank)).toEqual([1, 2, 3]);
    expect(view.capped).toBe(true);
    expect(view.holders).toBe(5);
  });

  it("is not capped when holders fit the window", () => {
    const view = buildLedger([acc(addr(1), 10)], 10, LEDGER_ROW_CAP);
    expect(view.capped).toBe(false);
  });

  it("computes topTenShare BEFORE the cap - a top-3 window still shows all ten", () => {
    // 12 holders, equal balances: top ten hold 10/12 of the supply even
    // when the rendered window shows only 3 rows.
    const accounts = Array.from({ length: 12 }, (_, i) => acc(addr(i), 10));
    const view = buildLedger(accounts, 120, 3);
    expect(view.topTenShare).toBeCloseTo(10 / 12, 10);
  });

  it("never fabricates ranks beyond the holder count", () => {
    const view = buildLedger([acc(addr(1), 5)], 5, 0);
    expect(view.rows).toHaveLength(0);
    expect(view.capped).toBe(true);
  });
});

describe("fmtSharePct", () => {
  it("formats whole and fractional percents", () => {
    expect(fmtSharePct(1)).toBe("100.00%");
    expect(fmtSharePct(0.5)).toBe("50.00%");
    expect(fmtSharePct(0.1234)).toBe("12.34%");
  });

  it("is honest about dust instead of printing 0.00%", () => {
    expect(fmtSharePct(0.00005)).toBe("<0.01%");
  });

  it("prints 0% for zero (and never crashes on junk)", () => {
    expect(fmtSharePct(0)).toBe("0%");
    expect(fmtSharePct(Number.NaN)).toBe("0%");
  });
});

describe("getLedger - the real storage read", () => {
  async function freshChain() {
    vi.resetModules();
    const chain = await import("./chain");
    const storage = new MemoryStorage();
    await chain.initChain(storage);
    return { chain, storage };
  }

  it("ranks the live account table against the recorded supply", async () => {
    const { chain, storage } = await freshChain();
    // Write straight into the bound storage: how rows arrived is consensus's
    // business; the ledger only reads the derived table.
    await storage.transact(async (tx) => {
      await tx.putAccount(acc(addr(1), 300, 4, 1));
      await tx.putAccount(acc(addr(2), 700, 0, 3));
      await tx.putAccount(acc(addr(3), 0)); // remembered, but empty
      await tx.setMeta("totalSupply", "1000");
    });

    const view = await chain.getLedger();
    expect(view.rows.map((r) => r.address)).toEqual([addr(2), addr(1)]);
    expect(view.rows[0]).toMatchObject({
      rank: 1,
      balance: 700,
      sent: 0,
      blocksMined: 3,
    });
    expect(view.rows[0].share).toBeCloseTo(0.7, 10);
    expect(view.holders).toBe(2);
    expect(view.emptyAccounts).toBe(1);
    expect(view.totalSupply).toBe(1000);
    expect(view.topTenShare).toBe(1);
    expect(view.capped).toBe(false);
  });

  it("honors a custom cap on the same live data", async () => {
    const { chain, storage } = await freshChain();
    await storage.transact(async (tx) => {
      for (let i = 0; i < 4; i++) await tx.putAccount(acc(addr(i), 40 - i * 10));
      await tx.setMeta("totalSupply", "100");
    });

    const view = await chain.getLedger(2);
    expect(view.rows.map((r) => r.balance)).toEqual([40, 30]);
    expect(view.capped).toBe(true);
    expect(view.holders).toBe(4);
  });

  it("a chain with no spendable history shows an empty ledger, not a crash", async () => {
    const { chain } = await freshChain();
    const view = await chain.getLedger();
    expect(view.rows).toHaveLength(0);
    expect(view.holders).toBe(0);
    expect(view.totalSupply).toBe(0);
  });
});
