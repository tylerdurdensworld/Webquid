/**
 * Chain state machine integration - memory adapter, REAL proof-of-work.
 * Genesis seal -> local mining -> transfer confirmation -> reorg rollback ->
 * a competing branch applied from "the wire" -> the chain heals forward.
 */
import { beforeAll, describe, expect, it } from "vitest";
import { sha256 } from "@noble/hashes/sha2.js";
import { bytesToHex, utf8ToBytes } from "@noble/hashes/utils.js";
import {
  GENESIS_TIMESTAMP,
  COIN,
  hashMeetsTarget,
  nowSeconds,
  serializeCoinbase,
  serializePopTransfer,
  splitBlockReward,
  type PopAttestation,
} from "@contracts/protocol";
import type { WireBlock } from "@contracts/wire";
import { signPopAttestation, signTransfer, walletFromPrivHex, type WalletKeys } from "@/lib/webquid";
import { dsha256Hex, merkleRootHex } from "./blockchain";
import {
  ChainValidationError,
  admitTransfer,
  applyWireBlock,
  buildTemplate,
  getAddressOverview,
  getInfo,
  getRecentBlocks,
  getMempool,
  getTipSummary,
  initChain,
  rollbackToHeight,
  setPopAttestationsProvider,
  setPopMinerNodeIdProvider,
  submitBlock,
  violatesMinerCooldown,
  type TemplateView,
} from "./chain";
import { MemoryStorage } from "./storage";

// -- PoW: baked solutions + live search fallback ----------------------------
// The narrative below is fully deterministic (fixed keys, fixed timestamps),
// so every block's winning nonce is constant. They were found once with the
// live search and are baked here - test runs verify them with ONE hash each
// instead of grinding ~2^22 hashes per block. Any narrative change simply
// falls back to the live search (slow but correct) and prints new solutions.
const BAKED: Record<string, { nonce: number; hash: string }> = {
  "WQD1|1|dae9a25d3573ed3fafc2571839396b57ca358840a15bbdaf5695b9d4642d0f55|94b188f363ae97aa3e38e4ae291beb48b97bd7da0900e74680253d869e07094d|1792540801|": { nonce: 1938197, hash: "000003916a24d67a8c9e5712890850417971068cb12967555f098dcb42da04d8" },
  "WQD1|2|000003916a24d67a8c9e5712890850417971068cb12967555f098dcb42da04d8|614a8e6f2bdca9a6c249010ad93256f7fae6d5a647db7832e99fb7235e8200a8|1792540802|": { nonce: 9669229, hash: "0000025f1731e24c3405cef7e3c8bafd60b12d243b6bdad3496d6932361afaf6" },
  "WQD1|3|0000025f1731e24c3405cef7e3c8bafd60b12d243b6bdad3496d6932361afaf6|45b2fe176c9f78edee163b16fa15877841bb6e06b2e81930209b25e829c6e19a|1792540803|": { nonce: 316450, hash: "0000017aabf6369cabbf52ce41abb960f3841b530a248cab40920ee3726d50e4" },
  "WQD1|3|0000025f1731e24c3405cef7e3c8bafd60b12d243b6bdad3496d6932361afaf6|d5887f5d954b99a85a76b089e258728380bdb8010a73ea35c20d5c747ed9ebb8|1792540803|": { nonce: 12139095, hash: "000003be0eb7e589143d7a001f259bc8141dba55f68d79d51230aca545f3f9ff" },
  "WQD1|4|0000017aabf6369cabbf52ce41abb960f3841b530a248cab40920ee3726d50e4|2e4ca48e6827621566e7d1f606ee488a2318611c976c199c1a04b5ee5c000ff7|1792540804|": { nonce: 154396, hash: "000002c7189f61e1e8413b07ff6bfd0fbb64b7481c34d1bac1c17c51757fa747" },
  "WQD1|5|000002c7189f61e1e8413b07ff6bfd0fbb64b7481c34d1bac1c17c51757fa747|90319a53c8dce167a2a0f669ea9684ac8b073a4d47c09870bb52abbd3ce4f341|1792540805|": { nonce: 4682193, hash: "00000301fa4c202830afccd043d9b31db4f8da3200c33137e54d34e4088de0a3" },
  "WQD1|6|00000301fa4c202830afccd043d9b31db4f8da3200c33137e54d34e4088de0a3|161a06f59e8502e8b11323fc6a1f1b31ff84e0150a8245bca4f63ee287da78eb|1792540806|": { nonce: 829632, hash: "00000009872a155434eb3eb6343aeff9f77a400522a03f060b0d5048a14ee83b" },
  "WQD1|7|00000009872a155434eb3eb6343aeff9f77a400522a03f060b0d5048a14ee83b|3225026073491beeb6bd67671c73dd0999260fdfb4da09eaf9b33d48de807c4a|1792540807|": { nonce: 1341955, hash: "0000028f63cf28a3e23abacbb8a56c2c31eb2111f225060ac9af88a1e9bdb78c" },
  "WQD1|7|00000009872a155434eb3eb6343aeff9f77a400522a03f060b0d5048a14ee83b|41ac02bbccc9e049f5bb8100f10f88e6e2e5d0408397e08f0ea71e96e29db93d|1792540807|": { nonce: 5381951, hash: "00000250785f17e514513e5c3dfcb8c399fb27c19805ade7f6fe000531fb6cd0" },
  "WQD1|7|00000009872a155434eb3eb6343aeff9f77a400522a03f060b0d5048a14ee83b|9d7483dabc3baee4abef734a2f7b37a9616cc417982e5d4c201c80965d142c11|1792540807|": { nonce: 4829503, hash: "00000369e7112a87a903327cab5c19112e46ce99911bdb3dc408fd5954e5674b" },
  "WQD1|7|00000009872a155434eb3eb6343aeff9f77a400522a03f060b0d5048a14ee83b|c47363f619d5bb8cf0641ece8ac712735a936be5847e6025d5e833655587f9c6|1792540807|": { nonce: 4513496, hash: "00000231bafb8a36186461f53d86de1f744766776a50c42152b2d293c1eda8a5" },
};

function powSearch(prefixAscii: string, target: string): { nonce: number; hash: string } {
  const baked = BAKED[prefixAscii];
  if (baked) {
    const prefix = utf8ToBytes(prefixAscii);
    const d1 = sha256.create().update(prefix).update(utf8ToBytes(String(baked.nonce))).digest();
    const hash = bytesToHex(sha256(d1));
    if (hash !== baked.hash || !hashMeetsTarget(hash, target)) {
      throw new Error(`baked solution invalid for ${prefixAscii}`);
    }
    return baked;
  }
  const prefix = utf8ToBytes(prefixAscii);
  for (let nonce = 0; nonce < 2 ** 31; nonce++) {
    const d1 = sha256.create().update(prefix).update(utf8ToBytes(String(nonce))).digest();
    const hash = bytesToHex(sha256(d1));
    if (hashMeetsTarget(hash, target)) {
      console.log(`BAKE: "${prefixAscii}": { nonce: ${nonce}, hash: "${hash}" },`);
      return { nonce, hash };
    }
  }
  throw new Error("nonce space exhausted");
}

async function mineNextBlock(miner: string): Promise<{ height: number; hash: string }> {
  const tpl: TemplateView = await buildTemplate(miner);
  const ts = tpl.minTimestamp; // deterministic - the whole narrative is
  const { nonce } = powSearch(
    `WQD1|${tpl.height}|${tpl.prevHash}|${tpl.merkleRoot}|${ts}|`,
    tpl.target,
  );
  return submitBlock(tpl.templateId, ts, nonce);
}

/**
 * Attestation-acceptance blocks MUST carry a wall-clock timestamp: the 300 s
 * freshness window is measured against the block's timestamp, so a block
 * carrying real attestations has to live in real time too. Non-deterministic
 * (live PoW every run) - only ever used for the LAST block of a narrative.
 */
async function mineNextBlockRealtime(miner: string): Promise<{ height: number; hash: string }> {
  // Live PoW can outlast the protocol's 120 s template TTL on a contended CI
  // worker. Do exactly what a real miner must do: request a fresh template and
  // attestations. Never relax submitBlock's expiry validation to accommodate it.
  for (let attempt = 0; attempt < 3; attempt++) {
    const tpl: TemplateView = await buildTemplate(miner);
    const ts = Math.max(tpl.minTimestamp, nowSeconds());
    const { nonce } = powSearch(
      `WQD1|${tpl.height}|${tpl.prevHash}|${tpl.merkleRoot}|${ts}|`,
      tpl.target,
    );
    try {
      return await submitBlock(tpl.templateId, ts, nonce);
    } catch (error) {
      const expired =
        error instanceof ChainValidationError &&
        error.message === "template expired - request a fresh one";
      if (!expired || attempt === 2) throw error;
    }
  }
  throw new Error("unreachable realtime-mining retry state");
}

/** A REAL peer-signed attestation - the exact bytes a wallet would produce. */
function attest(w: WalletKeys, minerPeerId: string, timestamp: number): PopAttestation {
  return {
    address: w.address,
    pubkey: w.pubHex,
    signature: signPopAttestation(w.privHex, { minerPeerId, address: w.address, timestamp }),
    timestamp,
  };
}
const TEST_NODE_ID = "wqd-test-miner-node";

/** Craft a valid coinbase-only block extending `storage`'s block at height-1. */
async function craftSideBlock(
  storage: MemoryStorage,
  height: number,
  miner: string,
): Promise<WireBlock> {
  const prev = await storage.blockAt(height - 1);
  if (!prev) throw new Error("side-block parent missing");
  const amount = splitBlockReward(height, 0).miner;
  const cbTxid = dsha256Hex(serializeCoinbase({ height, to: miner, amount }));
  const merkleRoot = merkleRootHex([cbTxid]);
  const ts = prev.timestamp + 1;
  const { nonce, hash } = powSearch(
    `WQD1|${height}|${prev.hash}|${merkleRoot}|${ts}|`,
    prev.target,
  );
  return {
    height,
    hash,
    prevHash: prev.hash,
    merkleRoot,
    timestamp: ts,
    nonce,
    target: prev.target,
    miner,
    message: null,
    txs: [
      {
        txid: cbTxid,
        type: "coinbase",
        fromAddress: null,
        toAddress: miner,
        amount,
        fee: 0,
        nonce: null,
        pubkey: null,
        signature: null,
        timestamp: ts,
      },
    ],
  };
}

// -- the narrative -----------------------------------------------------------
// Every block in this file is a bootstrap-era block with an empty PoP pool
// (unless a test announces peers): miner gets exactly the 70% share.
const MINER_SHARE = splitBlockReward(1, 0).miner;
const storage = new MemoryStorage();
let w1: WalletKeys; // mines the first blocks, sends the transfer
let w2: WalletKeys; // recipient
let w3: WalletKeys; // mines the competing branch

describe("browser chain node - full lifecycle", () => {
  beforeAll(async () => {
    await initChain(storage);
    // fixed keys -> a byte-deterministic narrative (baked PoW stays valid)
    w1 = walletFromPrivHex("01".repeat(32))!;
    w2 = walletFromPrivHex("02".repeat(32))!;
    w3 = walletFromPrivHex("03".repeat(32))!;
  }, 10_000);

  it("seals the deterministic genesis (hash pinned across every node)", async () => {
    const g = await storage.blockAt(0);
    expect(g?.hash).toBe(
      "dae9a25d3573ed3fafc2571839396b57ca358840a15bbdaf5695b9d4642d0f55",
    );
    expect(g?.timestamp).toBe(GENESIS_TIMESTAMP);
    const info = await getInfo();
    expect(info.height).toBe(0);
    expect(info.chainId).toBe("webquid-mainnet-2");
    expect(info.totalSupply).toBe(0);
  });

  it("mines two real blocks locally - subsidy lands", async () => {
    const b1 = await mineNextBlock(w1.address);
    expect(b1.height).toBe(1);
    const b2 = await mineNextBlock(w1.address);
    expect(b2.height).toBe(2);
    const acct = await getAddressOverview(w1.address);
    expect(acct.balance).toBe(2 * MINER_SHARE);
    expect(acct.blocksMined).toBe(2);
  }, 120_000);

  it("rejects garbage transfers before they touch the mempool", async () => {
    const unsigned = {
      from: w1.address,
      to: w2.address,
      amount: 10 * COIN,
      fee: 1_000,
      nonce: 0,
    };
    const goodSig = signTransfer(w1.privHex, unsigned);
    await expect(
      admitTransfer({ ...unsigned, pubkey: w1.pubHex, signature: goodSig, nonce: 7 }),
    ).rejects.toThrow(ChainValidationError);
    const forged = signTransfer(w3.privHex, unsigned); // wrong key for w1's address
    await expect(
      admitTransfer({ ...unsigned, pubkey: w1.pubHex, signature: forged }),
    ).rejects.toThrow(ChainValidationError);
  });

  it("confirms a signed transfer in the next block", async () => {
    const unsigned = {
      from: w1.address,
      to: w2.address,
      amount: 10 * COIN,
      fee: 1_000,
      nonce: 0,
    };
    const signature = signTransfer(w1.privHex, unsigned);
    const { txid } = await admitTransfer({ ...unsigned, pubkey: w1.pubHex, signature });
    expect(txid).toMatch(/^[0-9a-f]{64}$/);
    // re-admitting the same tx trips the state guard first (same as the
    // server reference: nonce rule precedes the duplicate check)
    await expect(
      admitTransfer({ ...unsigned, pubkey: w1.pubHex, signature }),
    ).rejects.toThrow(/bad nonce/);
    expect((await getMempool(10)).length).toBe(1);

    const b3 = await mineNextBlock(w1.address);
    expect(b3.height).toBe(3);
    expect((await getMempool(10)).length).toBe(0);
    const r = await getAddressOverview(w2.address);
    expect(r.balance).toBe(10 * COIN);
    const s = await getAddressOverview(w1.address);
    expect(s.nonce).toBe(1);
    // w1 mined block #3 itself, but the 1000-unit fee is BURNED in full -
    // it never comes back to anyone: 3 miner shares - 10 WQD sent - fee.
    expect(s.balance).toBe(3 * MINER_SHARE - 10 * COIN - 1_000);
  }, 120_000);

  it("rolls back one block exactly - mempool, balances, supply restored", async () => {
    await rollbackToHeight(2);
    const tip = await getTipSummary();
    expect(tip.height).toBe(2);
    expect((await getMempool(10)).length).toBe(1); // transfer is pending again
    const r = await getAddressOverview(w2.address);
    expect(r.balance).toBe(0);
    const s = await getAddressOverview(w1.address);
    expect(s.balance).toBe(2 * MINER_SHARE);
    expect(s.nonce).toBe(0);
    const info = await getInfo();
    expect(info.totalSupply).toBe(2 * MINER_SHARE);
  });

  it("applies a competing branch from the wire and keeps the pending tx", async () => {
    const side3 = await craftSideBlock(storage, 3, w3.address);
    await applyWireBlock(side3);
    const side4 = await craftSideBlock(storage, 4, w3.address);
    await applyWireBlock(side4);
    const tip = await getTipSummary();
    expect(tip.height).toBe(4);
    expect(tip.hash).toBe(side4.hash);

    const s = await getAddressOverview(w1.address);
    expect(s.balance).toBe(2 * MINER_SHARE); // block #3 reward stayed rolled back
    const m = await getAddressOverview(w3.address);
    expect(m.balance).toBe(2 * MINER_SHARE); // side branch paid w3
    expect((await getMempool(10)).length).toBe(1); // still pending
  }, 120_000);

  it("mines on the winning branch and confirms the long-pending transfer", async () => {
    const b5 = await mineNextBlock(w3.address);
    expect(b5.height).toBe(5);
    expect((await getMempool(10)).length).toBe(0);
    const r = await getAddressOverview(w2.address);
    expect(r.balance).toBe(10 * COIN);
    const s = await getAddressOverview(w1.address);
    expect(s.nonce).toBe(1);
    const info = await getInfo();
    expect(info.height).toBe(5);
  }, 120_000);

  it("rejects forged wire blocks with ChainValidationError", async () => {
    const tip = await getTipSummary();
    const fake = await craftSideBlock(storage, tip.height + 1, w3.address);
    fake.hash = "0".repeat(64); // lie about the header hash
    await expect(applyWireBlock(fake)).rejects.toThrow(ChainValidationError);
  }, 120_000);

  it("no attestations -> the whole 20% peer pool burns", async () => {
    setPopMinerNodeIdProvider(() => TEST_NODE_ID);
    setPopAttestationsProvider(() => []);
    const before = await getInfo();
    let mined: { height: number; hash: string };
    try {
      mined = await mineNextBlock(w3.address);
    } finally {
      setPopMinerNodeIdProvider(() => null);
    }
    expect(mined.height).toBe(6);
    const after = await getInfo();
    // only the miner's 70% was minted - the unattested pool never existed
    expect(after.totalSupply - before.totalSupply).toBe(splitBlockReward(6, 0).miner);
  }, 120_000);

  it("rejects blocks whose PoP attestations fail in any way", async () => {
    const tip = await getTipSummary();
    const height = tip.height + 1; // 7
    const ts = (await storage.blockAt(height - 1))!.timestamp + 1; // deterministic
    const good1 = splitBlockReward(height, 1);
    const good2 = splitBlockReward(height, 2);

    // (a) INVALID SIGNATURE - garbage bytes where a signature should be
    const badSig = await craftSideBlockFull(
      storage, height, w3.address,
      [{ address: w1.address, amount: good1.perPeer, index: 0 }],
      [{ ...attest(w1, TEST_NODE_ID, ts), signature: "cd".repeat(64) }],
    );
    await expect(applyWireBlock(badSig)).rejects.toThrow(/PoP/);

    // (b) WRONG ADDRESS - the attestation pays w2, the block pays w1
    const wrongAddr = await craftSideBlockFull(
      storage, height, w3.address,
      [{ address: w1.address, amount: good1.perPeer, index: 0 }],
      [attest(w2, TEST_NODE_ID, ts)],
    );
    await expect(applyWireBlock(wrongAddr)).rejects.toThrow(/PoP/);

    // (c) EXPIRED - signed 301 s before the block's timestamp
    const expired = await craftSideBlockFull(
      storage, height, w3.address,
      [{ address: w1.address, amount: good1.perPeer, index: 0 }],
      [attest(w1, TEST_NODE_ID, ts - 301)],
    );
    await expect(applyWireBlock(expired)).rejects.toThrow(/PoP/);

    // (d) UNATTESTED PEER - the miner pays w1 AND w2, but only w1 attested
    const unattested = await craftSideBlockFull(
      storage, height, w3.address,
      [
        { address: w1.address, amount: good2.perPeer, index: 0 },
        { address: w2.address, amount: good2.perPeer, index: 1 },
      ],
      [attest(w1, TEST_NODE_ID, ts)],
    );
    await expect(applyWireBlock(unattested)).rejects.toThrow(/PoP/);

    // (e) NOT THE EQUAL SPLIT - greedy share, attestation itself valid
    const greedy = await craftSideBlockFull(
      storage, height, w3.address,
      [{ address: w1.address, amount: good1.perPeer + 1, index: 0 }],
      [attest(w1, TEST_NODE_ID, ts)],
    );
    await expect(applyWireBlock(greedy)).rejects.toThrow(/PoP/);

    // (f) SELF-PAYMENT - the miner "attests" itself with its own key
    const selfPay = await craftSideBlockFull(
      storage, height, w3.address,
      [{ address: w3.address, amount: good1.perPeer, index: 0 }],
      [attest(w3, TEST_NODE_ID, ts)],
    );
    await expect(applyWireBlock(selfPay)).rejects.toThrow(/PoP/);
  }, 300_000);

  it("valid attestations -> block accepted, pool split equally, burn never mints", async () => {
    const before = await getInfo();
    const [a1, a2, a3] = await Promise.all([
      getAddressOverview(w1.address),
      getAddressOverview(w2.address),
      getAddressOverview(w3.address),
    ]);
    // real signatures, real time - the last block of the narrative (its hash
    // is wall-clock-dependent, so nothing deterministic follows it)
    setPopMinerNodeIdProvider(() => TEST_NODE_ID);
    setPopAttestationsProvider(() => [
      attest(w1, TEST_NODE_ID, nowSeconds()),
      attest(w2, TEST_NODE_ID, nowSeconds()),
      attest(w1, TEST_NODE_ID, nowSeconds()), // duplicate - freshest wins
    ]);
    let mined: { height: number; hash: string };
    try {
      mined = await mineNextBlockRealtime(w3.address);
    } finally {
      setPopAttestationsProvider(() => []);
      setPopMinerNodeIdProvider(() => null);
    }
    expect(mined.height).toBe(7);

    const split = splitBlockReward(7, 2);
    const [b1, b2, b3] = await Promise.all([
      getAddressOverview(w1.address),
      getAddressOverview(w2.address),
      getAddressOverview(w3.address),
    ]);
    expect(b3.balance - a3.balance).toBe(split.miner);
    expect(b1.balance - a1.balance).toBe(split.perPeer);
    expect(b2.balance - a2.balance).toBe(split.perPeer);
    const after = await getInfo();
    expect(after.totalSupply - before.totalSupply).toBe(split.miner + 2 * split.perPeer);

    // the stored block carries the full attestation evidence for sync peers
    const stored = await storage.blockAt(7);
    expect(stored?.minerPeerId).toBe(TEST_NODE_ID);
    expect(stored?.popAttestations.length).toBe(2);
  }, 300_000);
});

/** Like craftSideBlock, but commits to explicit PoP payouts + attestations. */
async function craftSideBlockFull(
  storage: MemoryStorage,
  height: number,
  miner: string,
  pops: Array<{ address: string; amount: number; index: number }>,
  atts: PopAttestation[],
): Promise<WireBlock> {
  const prev = await storage.blockAt(height - 1);
  if (!prev) throw new Error("side-block parent missing");
  const amount = splitBlockReward(height, pops.length).miner;
  const cbTxid = dsha256Hex(serializeCoinbase({ height, to: miner, amount }));
  const popIds = pops.map((pop) =>
    dsha256Hex(
      serializePopTransfer({ height, index: pop.index, to: pop.address, amount: pop.amount }),
    ),
  );
  const merkleRoot = merkleRootHex([cbTxid, ...popIds]);
  const ts = prev.timestamp + 1;
  const { nonce, hash } = powSearch(
    `WQD1|${height}|${prev.hash}|${merkleRoot}|${ts}|`,
    prev.target,
  );
  return {
    height,
    hash,
    prevHash: prev.hash,
    merkleRoot,
    timestamp: ts,
    nonce,
    target: prev.target,
    miner,
    message: null,
    popTransfers: pops,
    minerPeerId: TEST_NODE_ID,
    popAttestations: atts,
    txs: [
      {
        txid: cbTxid,
        type: "coinbase",
        fromAddress: null,
        toAddress: miner,
        amount,
        fee: 0,
        nonce: null,
        pubkey: null,
        signature: null,
        timestamp: ts,
      },
    ],
  };
}

describe("miner cooldown (consensus from block 2,000)", () => {
  it("no address may mine two consecutive blocks once active", () => {
    const a = "wqd1aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa";
    const b = "wqd1bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb";
    expect(violatesMinerCooldown(1, a, a)).toBe(false); // bootstrap era
    expect(violatesMinerCooldown(1_999, a, a)).toBe(false); // below activation
    expect(violatesMinerCooldown(2_000, a, b)).toBe(false); // rotation is fine
    expect(violatesMinerCooldown(2_000, a, null)).toBe(false); // unknown parent
    expect(violatesMinerCooldown(2_000, a, a)).toBe(true); // consecutive self
    expect(violatesMinerCooldown(9_999, a, a)).toBe(true); // stays enforced
  });

  it("below activation a repeat miner still gets a template (the gate opens only at 2,000)", async () => {
    const tip = await getTipSummary();
    expect(tip.height).toBeLessThan(2_000);
    const tipBlock = (await getRecentBlocks(1))[0];
    const tpl = await buildTemplate(tipBlock.miner); // same miner again - allowed here
    expect(tpl.height).toBe(tip.height + 1);
    // ...but that exact pairing becomes a violation the moment the gate opens:
    expect(violatesMinerCooldown(2_000, tipBlock.miner, tipBlock.miner)).toBe(true);
  });
});
