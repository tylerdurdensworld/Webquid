/**
 * Import safety - the chain can never be downgraded by a file, and the
 * balance math has a numeric proof.
 *
 *   - SHORTER file: rejected by default (ChainDowngradeError), local chain
 *     and balances intact - even { replace: true } alone is not enough.
 *     Only { replace, allowDowngrade } (the UI's dangerous override, which
 *     shows both heights and both tip hashes) applies it - and logs it.
 *   - EQUAL height, same tip: "already up to date" no-op.
 *   - EQUAL height, different tip: fork conflict, default = keep local.
 *   - LONGER valid file: applied directly (the normal case).
 *   - LONGER invalid file: rejected before a single write.
 *   - NUMERIC PROOF: the known 14-block reference chain (heights 0-13, 13
 *     coinbases of 350 WQD to one address) imported on an EMPTY node gives
 *     balance === spendable === 4550 WQD, topbar compact "4.55k".
 */
import { describe, expect, it, vi } from "vitest";
import { sha256 } from "@noble/hashes/sha2.js";
import { bytesToHex, utf8ToBytes } from "@noble/hashes/utils.js";
import { COIN, hashMeetsTarget, splitBlockReward } from "@contracts/protocol";
import { walletFromPrivHex } from "@/lib/webquid";
import { fmtCompact } from "@/lib/format";
import { MemoryStorage } from "./storage";

const w1 = walletFromPrivHex("01".repeat(32))!;
const w2 = walletFromPrivHex("02".repeat(32))!;

const BAKED: Record<string, { nonce: number; hash: string }> = {
  "WQD1|10|000000457e76bad1da5191fe1dba16a7a3c8a24a1cbca7547a98227eeba2ef7b|18c146d43f96478fd2a871d1c9a4984cb7fad7e1b5ccea02e3740a417251ec40|1792540810|": { nonce: 3631687, hash: "000000083c1a9a66a7b78a74f737887a29d0668594faef2f1e2c049037c92719" },
  "WQD1|11|000000083c1a9a66a7b78a74f737887a29d0668594faef2f1e2c049037c92719|1859ad76362f58a33daf1256ebf060f07bf925c3c47749f1757fbb1ab0fc0023|1792540811|": { nonce: 22394224, hash: "0000006a59c0c1fc48f4520881852bd661588005c2f3a8f31d7ab94c78d7958f" },
  "WQD1|12|0000006a59c0c1fc48f4520881852bd661588005c2f3a8f31d7ab94c78d7958f|2861054c99cae2ebc47e00280af2c5effaf3abd879255b33493c841463e45182|1792540812|": { nonce: 10302332, hash: "0000002a2823c56d3ed7f7057d12ebc5170febbe8a49e9441def1e5309321592" },
  "WQD1|13|0000002a2823c56d3ed7f7057d12ebc5170febbe8a49e9441def1e5309321592|e22e762786697bf1659178c39e68a6bbc6338b112dd5754112292b19304061f9|1792540813|": { nonce: 22838305, hash: "0000007a41be958bb97a8d8290d89938d44e74a355cb98264d511573dcb0fb24" },
  "WQD1|1|dae9a25d3573ed3fafc2571839396b57ca358840a15bbdaf5695b9d4642d0f55|94b188f363ae97aa3e38e4ae291beb48b97bd7da0900e74680253d869e07094d|1792540801|": { nonce: 1938197, hash: "000003916a24d67a8c9e5712890850417971068cb12967555f098dcb42da04d8" },
  "WQD1|1|dae9a25d3573ed3fafc2571839396b57ca358840a15bbdaf5695b9d4642d0f55|c65767d2fb627992bde5085b987093788ab9ff40deb1ea9e74f3492d7adb5fb3|1792540801|": { nonce: 13534355, hash: "000003df1ab638d3a6af837afe3ac96ddca2b314ac75b12e1b8e6bc1ca895714" },
  "WQD1|2|000003916a24d67a8c9e5712890850417971068cb12967555f098dcb42da04d8|614a8e6f2bdca9a6c249010ad93256f7fae6d5a647db7832e99fb7235e8200a8|1792540802|": { nonce: 9669229, hash: "0000025f1731e24c3405cef7e3c8bafd60b12d243b6bdad3496d6932361afaf6" },
  "WQD1|3|0000025f1731e24c3405cef7e3c8bafd60b12d243b6bdad3496d6932361afaf6|998b82684c9cdbbf875774531a8ff85e359de44c01061dbaab0ba1e28cc3da8a|1792540803|": { nonce: 7516664, hash: "00000030714fb7dbf776bd70d289e5ef488ce0c0c29bc978cf1f8899b3e216e1" },
  "WQD1|4|00000030714fb7dbf776bd70d289e5ef488ce0c0c29bc978cf1f8899b3e216e1|da0085c2c80edc649c4dfe7b6baab05d1aa48a94f8667bfe30edf7744abcb920|1792540804|": { nonce: 8044059, hash: "000001914544f5ca527c2b966802a5ecc28ddc3d2e1e68057431237a0aeee71c" },
  "WQD1|5|000001914544f5ca527c2b966802a5ecc28ddc3d2e1e68057431237a0aeee71c|429901c20adb603092bf504997c1527d4b326db80fb043c55e00e69cb4cf1588|1792540805|": { nonce: 4617523, hash: "0000013c9d5feee56bb9161a25efe3b433117761e26e0ad2a2604979d50c58ed" },
  "WQD1|6|0000013c9d5feee56bb9161a25efe3b433117761e26e0ad2a2604979d50c58ed|b7b13d0e1e184ee791d83d346c88a47cfe785ae1aeccbbc494286aa61fdf2858|1792540806|": { nonce: 4730374, hash: "00000184e4c8029bf85f0142a39a5b38a4e77d440d467ba84300025265a25632" },
  "WQD1|7|00000184e4c8029bf85f0142a39a5b38a4e77d440d467ba84300025265a25632|15a5b153d783291abc9a5ccd70789a261ea7f6bd1ff9e816d8637e6bf0a2181f|1792540807|": { nonce: 4649234, hash: "0000035e9c537b8f7842181396cd7b4d905cdc8fa625952f568e6f9e3a483c6a" },
  "WQD1|8|0000035e9c537b8f7842181396cd7b4d905cdc8fa625952f568e6f9e3a483c6a|aa8eff39947da3628e5bd7e52fd792948be6400561a70be0403a912b86ba98ef|1792540808|": { nonce: 8876859, hash: "000000bb52e7f497c6f5de69e02de9d75117c3cf4a00d4268456f39b06e459a1" },
  "WQD1|9|000000bb52e7f497c6f5de69e02de9d75117c3cf4a00d4268456f39b06e459a1|3690eb1d34349700e07b43050f80d5827bb45d8abdcdecf5b4420e3fc5b70922|1792540809|": { nonce: 2281071, hash: "000000457e76bad1da5191fe1dba16a7a3c8a24a1cbca7547a98227eeba2ef7b" },
};

function powSearch(prefixAscii: string, target: string): { nonce: number; hash: string } {
  const baked = BAKED[prefixAscii];
  if (baked) return baked;
  const prefix = utf8ToBytes(prefixAscii);
  for (let nonce = 0; nonce < 2 ** 31; nonce++) {
    const d1 = sha256.create().update(prefix).update(utf8ToBytes(String(nonce))).digest();
    const hash = bytesToHex(sha256(d1));
    if (hashMeetsTarget(hash, target)) {
      console.log(`BAKE: "${prefixAscii}": { nonce: ${nonce}, hash: "${hash}" },`);
      return { nonce, hash };
    }
  }
  throw new Error("nonce space exhausted");
}

type ChainModule = typeof import("./chain");

async function freshChain(): Promise<ChainModule> {
  vi.resetModules();
  const chain = await import("./chain");
  await chain.initChain(new MemoryStorage());
  return chain;
}

async function mineOne(chain: ChainModule, miner: string): Promise<{ height: number; hash: string }> {
  const tpl = await chain.buildTemplate(miner);
  const ts = tpl.minTimestamp;
  const { nonce } = powSearch(
    `WQD1|${tpl.height}|${tpl.prevHash}|${tpl.merkleRoot}|${ts}|`,
    tpl.target,
  );
  const r = await chain.submitBlock(tpl.templateId, ts, nonce);
  return { height: r.height, hash: r.hash };
}

function asFile(data: unknown): unknown {
  return JSON.parse(JSON.stringify(data));
}

describe("import safety - never downgrade the chain", () => {
  it("NUMERIC PROOF: 13 x 350 WQD coinbases on an empty node -> 4550 / 4550 / compact", async () => {
    const src = await freshChain();
    for (let h = 1; h <= 13; h++) await mineOne(src, w1.address);
    const data = asFile(await src.exportChain());

    const dst = await freshChain(); // EMPTY node (genesis only)
    const res = await dst.importChain(data);
    expect(res).toEqual({ height: 13, applied: true });

    const perBlock = splitBlockReward(1, 0).miner; // 350 WQD - the 70% share
    expect(perBlock).toBe(350 * COIN);
    const expected = 13 * perBlock; // 4,550 WQD - no double counting of anything
    const view = await dst.getAddressOverview(w1.address);
    expect(view.balance).toBe(expected);
    expect(view.available).toBe(expected); // no pending outgoing
    expect(view.balance).toBe(4550 * COIN);
    expect(view.available).toBe(4550 * COIN);
    expect(fmtCompact(view.balance)).toBe("4.55k"); // the topbar figure in "WQD: 4.55k"
    // the whole supply is exactly those 13 coinbases - nothing else exists
    expect((await dst.getInfo()).totalSupply).toBe(expected);
  }, 300_000);

  it("a SHORTER file is rejected by default - local chain and balance intact", async () => {
    const src = await freshChain();
    const b1 = await mineOne(src, w1.address);
    const shortFile = asFile(await src.exportChain()); // height 1

    const local = await freshChain();
    await local.importChain(shortFile);
    await mineOne(local, w1.address);
    const tip = await mineOne(local, w1.address); // local is now height 3
    const balBefore = (await local.getAddressOverview(w1.address)).balance;

    const err = await local.importChain(shortFile).catch((e) => e);
    expect(err).toBeInstanceOf(local.ChainDowngradeError);
    expect(err.kind).toBe("downgrade");
    expect(err.local).toEqual({ height: 3, hash: tip.hash });
    expect(err.incoming).toEqual({ height: 1, hash: b1.hash });
    expect(err.message).toMatch(/SHORTER \(H:1\) than your local chain \(H:3\)/);
    expect(err.message).toMatch(/lose 2 block\(s\)/);

    // untouched: tip, balance, and spendable are exactly what they were
    expect((await local.getInfo()).tipHash).toBe(tip.hash);
    const view = await local.getAddressOverview(w1.address);
    expect(view.balance).toBe(balBefore);
    expect(view.available).toBe(balBefore);
  }, 300_000);

  it("{ replace: true } alone is NOT enough for a downgrade", async () => {
    const src = await freshChain();
    await mineOne(src, w1.address);
    const shortFile = asFile(await src.exportChain());

    const local = await freshChain();
    await local.importChain(shortFile);
    await mineOne(local, w1.address);
    const tip = await local.getTipSummary();

    await expect(local.importChain(shortFile, { replace: true })).rejects.toBeInstanceOf(
      local.ChainDowngradeError,
    );
    expect((await local.getTipSummary()).hash).toBe(tip.hash);
  }, 300_000);

  it("dangerous override: shorter file applies ONLY with replace + allowDowngrade, and is logged", async () => {
    const src = await freshChain();
    const b1 = await mineOne(src, w1.address);
    const shortFile = asFile(await src.exportChain());

    const local = await freshChain();
    await local.importChain(shortFile);
    await mineOne(local, w1.address);
    await mineOne(local, w1.address); // local height 3

    const warn = vi.spyOn(console, "warn").mockImplementation(() => undefined);
    const res = await local.importChain(shortFile, { replace: true, allowDowngrade: true });
    expect(res).toEqual({ height: 1, applied: true });
    expect((await local.getTipSummary()).hash).toBe(b1.hash);
    // the override is on record - both heights, both tip hashes
    const logged = warn.mock.calls.map((c) => String(c[0])).join("\n");
    expect(logged).toMatch(/DANGEROUS OVERRIDE/);
    expect(logged).toContain(b1.hash);
    warn.mockRestore();
  }, 300_000);

  it("equal height, same tip -> already up to date, zero change", async () => {
    const src = await freshChain();
    await mineOne(src, w1.address);
    const data = asFile(await src.exportChain());

    const dst = await freshChain();
    await dst.importChain(data);
    const res = await dst.importChain(data);
    expect(res).toEqual({ height: 1, applied: false });
  }, 300_000);

  it("equal height, different tip -> fork warning, default keeps local", async () => {
    const src = await freshChain();
    const fileTip = await mineOne(src, w1.address);
    const data = asFile(await src.exportChain());

    const local = await freshChain();
    const localTip = await mineOne(local, w2.address); // same height, other chain

    const err = await local.importChain(data).catch((e) => e);
    expect(err).toBeInstanceOf(local.ChainConflictError);
    expect(err.kind).toBe("fork");
    expect(err.local.hash).toBe(localTip.hash);
    expect(err.incoming.hash).toBe(fileTip.hash);
    // default = keep local
    expect((await local.getTipSummary()).hash).toBe(localTip.hash);
    // explicit opt-in replaces
    const res = await local.importChain(data, { replace: true });
    expect(res).toEqual({ height: 1, applied: true });
    expect((await local.getTipSummary()).hash).toBe(fileTip.hash);
  }, 300_000);

  it("a LONGER valid file applies directly - the normal case needs no confirmation", async () => {
    const src = await freshChain();
    await mineOne(src, w1.address);
    await mineOne(src, w1.address);
    const fileTip = await mineOne(src, w1.address); // height 3
    const data = asFile(await src.exportChain());

    const local = await freshChain();
    await mineOne(local, w2.address); // a DIFFERENT local chain, height 1

    const res = await local.importChain(data); // no replace flag at all
    expect(res).toEqual({ height: 3, applied: true });
    expect((await local.getTipSummary()).hash).toBe(fileTip.hash);
    // balances recomputed from the resulting chain: w2's local history is gone
    expect((await local.getAddressOverview(w2.address)).balance).toBe(0);
    expect((await local.getAddressOverview(w1.address)).balance).toBe(3 * 350 * COIN);
  }, 300_000);

  it("a LONGER invalid file is rejected - local chain fully intact", async () => {
    const src = await freshChain();
    await mineOne(src, w1.address);
    await mineOne(src, w1.address);
    const data = asFile(await src.exportChain()) as Awaited<ReturnType<typeof src.exportChain>>;
    data.blocks[2].txs[0].amount += 1; // forged coinbase on the longer chain

    const local = await freshChain();
    const localTip = await mineOne(local, w2.address);
    await expect(local.importChain(data)).rejects.toThrow(/coinbase|amount/i);
    expect((await local.getTipSummary()).hash).toBe(localTip.hash);
    expect((await local.getAddressOverview(w2.address)).balance).toBe(350 * COIN);
  }, 300_000);
});
