/**
 * Pruning under a hostile lens: the opt-in history prune must delete ONLY
 * confirmed tx rows below the horizon, refuse anything inside the reorg
 * window, keep headers/balances/supply/tip perfectly intact, and the node
 * must keep mining and validating afterwards. A pruned node must also
 * REFUSE a full-chain export loudly (its history has holes).
 */
import { beforeAll, describe, expect, it } from "vitest";
import { sha256 } from "@noble/hashes/sha2.js";
import { bytesToHex, utf8ToBytes } from "@noble/hashes/utils.js";
import { GENESIS_TIMESTAMP, TARGET_BLOCK_TIME, hashMeetsTarget } from "@contracts/protocol";
import { walletFromPrivHex } from "@/lib/webquid";
import {
  ChainValidationError,
  buildTemplate,
  exportChain,
  getAddressOverview,
  getInfo,
  getWireBlock,
  initChain,
  pruneConfirmedTxsBelow,
  submitBlock,
} from "./chain";
import { MemoryStorage } from "./storage";

const w1 = walletFromPrivHex("01".repeat(32))!;
const PRUNE_NARRATIVE_BLOCKS = 35;

// Coinbase-only chain to w1: every preimage is deterministic, so nonces are
// baked after the first live grind (see chain.test.ts for the pattern).
const BAKED: Record<string, { nonce: number; hash: string }> = {
  "WQD1|10|0000032fbe3f89248ed2eb80b718c84a35db14e9de10d762c2833cfc1a8faec0|18c146d43f96478fd2a871d1c9a4984cb7fad7e1b5ccea02e3740a417251ec40|1792541400|": { nonce: 1702010, hash: "0000017268c8c90616b52e5032d35a7294a0a0fd7cd8abe5749d10f8bc178b82" },
  "WQD1|11|0000017268c8c90616b52e5032d35a7294a0a0fd7cd8abe5749d10f8bc178b82|1859ad76362f58a33daf1256ebf060f07bf925c3c47749f1757fbb1ab0fc0023|1792541460|": { nonce: 602279, hash: "0000007f3a3836c515dda7ec34b560e6601a88c539d27a25087598b0e6a38962" },
  "WQD1|12|0000007f3a3836c515dda7ec34b560e6601a88c539d27a25087598b0e6a38962|2861054c99cae2ebc47e00280af2c5effaf3abd879255b33493c841463e45182|1792541520|": { nonce: 1397712, hash: "00000188817246c3aa7a0961814b9f4b69cd6ca7356e9accc40121486aa6402c" },
  "WQD1|13|00000188817246c3aa7a0961814b9f4b69cd6ca7356e9accc40121486aa6402c|e22e762786697bf1659178c39e68a6bbc6338b112dd5754112292b19304061f9|1792541580|": { nonce: 756536, hash: "0000018e37732823afc06fe8b6c3d0644a16fdf7d3a7ba0f459f1c92cc6f2638" },
  "WQD1|14|0000018e37732823afc06fe8b6c3d0644a16fdf7d3a7ba0f459f1c92cc6f2638|873e2dd8b643636185dc9467b350cd5bb4d6cfd114252e19bd05ae8380168639|1792541640|": { nonce: 1428768, hash: "0000003bf668f22f9a44e5bdca2e7649d27b2c2b1da1d635f76994045313dac7" },
  "WQD1|15|0000003bf668f22f9a44e5bdca2e7649d27b2c2b1da1d635f76994045313dac7|8fdb0611e6316ed8f4efa926c2cc4e117b11d28068688cf4f442dad6ec2994bf|1792541700|": { nonce: 690965, hash: "000002474e4cf86994efa63fc8a70e05b088002209716220f8abc612290f122d" },
  "WQD1|16|000002474e4cf86994efa63fc8a70e05b088002209716220f8abc612290f122d|544416326a5de7ad94311a7d878dc20856472e590969ef3a9bb338917f1647fd|1792541760|": { nonce: 11156420, hash: "00000248a711ed98f37dce0cac077fce4f04c2b0bf287a3224eeaf5dfe7329d9" },
  "WQD1|17|00000248a711ed98f37dce0cac077fce4f04c2b0bf287a3224eeaf5dfe7329d9|2b0170197cba8a6500a51cc8efc33de79ddcde7132b2216dbf43958c15461219|1792541820|": { nonce: 1152680, hash: "00000292892996af6c664e77ec9b4946e21a94709086201c3cdbb714964a3466" },
  "WQD1|18|00000292892996af6c664e77ec9b4946e21a94709086201c3cdbb714964a3466|c7aa7cce2c654a18addb11c69879492eeeddc786b44f5e284d07b33380958030|1792541880|": { nonce: 2087347, hash: "0000026d91481b80947f3396c18ac6534b0106d17831cd6166e8f4ab35539774" },
  "WQD1|19|0000026d91481b80947f3396c18ac6534b0106d17831cd6166e8f4ab35539774|38417129f354c717c8649c368d594544c9accd96098606e41bd9159cd5779a0a|1792541940|": { nonce: 14824563, hash: "0000018642b671a2c299c1fa9f73664acbf32ab606ee3c216e8361d2cf6cf0ed" },
  "WQD1|1|dae9a25d3573ed3fafc2571839396b57ca358840a15bbdaf5695b9d4642d0f55|94b188f363ae97aa3e38e4ae291beb48b97bd7da0900e74680253d869e07094d|1792540860|": { nonce: 9776867, hash: "0000007b4b4646cafad860e148c512e55e949c22cacce4e308dc7d3b568f81aa" },
  "WQD1|20|0000018642b671a2c299c1fa9f73664acbf32ab606ee3c216e8361d2cf6cf0ed|fed7705bac97a25f2732dcfa09d348bb1f4d084b5a4bea693bdfc8afa35b8cb3|1792542000|": { nonce: 1458447, hash: "0000027b3e98ad60b315bf752434b1c6f23d139192d2bce8ff84946290ddab93" },
  "WQD1|21|0000027b3e98ad60b315bf752434b1c6f23d139192d2bce8ff84946290ddab93|73f1f6807bff8101c97b8da1d0d47c60c7ceb8dbf93a5ca7fc0f701602d73442|1792542060|": { nonce: 1097555, hash: "00000201418310475a69f9c436230c5456a8ce268996148f5dbe96a0ce5b4c47" },
  "WQD1|22|00000201418310475a69f9c436230c5456a8ce268996148f5dbe96a0ce5b4c47|ca5d4420fc8b493e88f0384eb3d8b85e6c8a158dbb82de59a4d45cc2091fe6a3|1792542120|": { nonce: 4317648, hash: "000000cac5f331046bcad27b626010c54ebbe2cacfbf9ac3c2ba9a1bf9267711" },
  "WQD1|23|000000cac5f331046bcad27b626010c54ebbe2cacfbf9ac3c2ba9a1bf9267711|6518f2d2d2452c2b1a0263c2b38d74f8d65fd4909cce70f466092ce3f049d5a8|1792542180|": { nonce: 29080, hash: "000000eadd98d89ef1b5eac3ab8d277c043780b786fdb70a27ec53644dd1a78c" },
  "WQD1|24|000000eadd98d89ef1b5eac3ab8d277c043780b786fdb70a27ec53644dd1a78c|72e89e3020bc35172b44802cca4069325e26f832b4057ddf76c5dc4e3c62cec7|1792542240|": { nonce: 19213346, hash: "0000027cbc103e69fc4380d485bc7d5bc0a2ff7a46ac5e47fadf5c4efaeef253" },
  "WQD1|25|0000027cbc103e69fc4380d485bc7d5bc0a2ff7a46ac5e47fadf5c4efaeef253|066e221ff7872e56aaf43ce2f80da58980f243b28596f15ad123e3f375a88b0a|1792542300|": { nonce: 2821242, hash: "0000014441c04b1797d25ba762fecffedefd3449c4707bfab9db2724e02e7e1d" },
  "WQD1|26|0000014441c04b1797d25ba762fecffedefd3449c4707bfab9db2724e02e7e1d|c5869d5029bacf4b355406bc3ec5bb5796b806d7395b3334e1e845bb09f42ea2|1792542360|": { nonce: 3677691, hash: "0000013edf4e8ef7e061b7cd306d7ccc2b1059435fa04ebe6081188cec6f1c6f" },
  "WQD1|27|0000013edf4e8ef7e061b7cd306d7ccc2b1059435fa04ebe6081188cec6f1c6f|5485090488d4b4c34c33ee270eea8f46dbef91459b11d7ea72a9e3a32e82a509|1792542420|": { nonce: 233782, hash: "00000138c0f88c47f0047912746a05652add2352773a920c4048b79a3788c2a0" },
  "WQD1|28|00000138c0f88c47f0047912746a05652add2352773a920c4048b79a3788c2a0|616c2b56960293c1f7f3dedc9a73a0530b132356a16a1f6d66ce1b171a8737df|1792542480|": { nonce: 3491979, hash: "000001e7f0d7e83bf407b19f7f8ef4c0b55f903c8a993f17b924c184d69fab32" },
  "WQD1|29|000001e7f0d7e83bf407b19f7f8ef4c0b55f903c8a993f17b924c184d69fab32|15e5037672d03534f3dbd126863be3abde741d34c0f5f9d52811054b9a6daa25|1792542540|": { nonce: 11981353, hash: "0000000f72765aa67e2c4ab03096c2f23053ad352896983964713dd9b023ff5e" },
  "WQD1|2|0000007b4b4646cafad860e148c512e55e949c22cacce4e308dc7d3b568f81aa|614a8e6f2bdca9a6c249010ad93256f7fae6d5a647db7832e99fb7235e8200a8|1792540920|": { nonce: 1853856, hash: "0000006e18ee160a111760bff2126ba1fa352ddede88c0500d6574b21d3984ee" },
  "WQD1|30|0000000f72765aa67e2c4ab03096c2f23053ad352896983964713dd9b023ff5e|7263636e40a1d83da88d7086519a1fafa93ccc6ffe15497905a664bb91e80ba4|1792542600|": { nonce: 11834519, hash: "000001087f0567cae87bd69a827c5a63772f69605793cb36c7827572c296a3ac" },
  "WQD1|31|000001087f0567cae87bd69a827c5a63772f69605793cb36c7827572c296a3ac|a6cdbd47736c21362011d6873d708c3429f4cab1dd51045a28db8de48b256ac0|1792542660|": { nonce: 7927522, hash: "000001be98a9f1b933cda7b0b1da259c93cd7813647786e382075686b0169eee" },
  "WQD1|32|000001be98a9f1b933cda7b0b1da259c93cd7813647786e382075686b0169eee|65370b3f67cde68f45422ee5aaaa3501b6494dc5b403c56c44dfa30d2ad65a95|1792542720|": { nonce: 6602777, hash: "00000230d9123b8fa21ff1e6e947d4d676f403e41ae448084136b7af9d639bdd" },
  "WQD1|33|00000230d9123b8fa21ff1e6e947d4d676f403e41ae448084136b7af9d639bdd|c229972c8469af95f87d7ecb702feef48672afadff07424e055c871605f10740|1792542780|": { nonce: 3036687, hash: "000000a260c6ad9be0ef88108a02960e11d71550417304b7293e2c7048865ffa" },
  "WQD1|34|000000a260c6ad9be0ef88108a02960e11d71550417304b7293e2c7048865ffa|5790613ba3220225513b3faf0e074dd29e74585ec26fe1e87a9c8e1ee39acd81|1792542840|": { nonce: 6716967, hash: "0000014d08a5e3d31834cd37cc3458efb139ea1b12253e872480d2ca091b55ce" },
  "WQD1|35|0000014d08a5e3d31834cd37cc3458efb139ea1b12253e872480d2ca091b55ce|2e41d0ce1a8eacb882339b9f064bf5e528d6e4806d5803897f0161297874d771|1792542900|": { nonce: 19188702, hash: "000000abaad3dbfc811389f4a6d8757da19d26b92d3db7d19ed7b4a71aea9839" },
  "WQD1|36|000000abaad3dbfc811389f4a6d8757da19d26b92d3db7d19ed7b4a71aea9839|1519a975664ebf3d29515ee6dcd9f9e43468e9ffb00165ee9cb92fc4848c072c|1792542960|": { nonce: 7415240, hash: "0000001e20ae9d84ed451be0c6a22d68bacf3591dd5597b0f23fb909378cde2c" },
  "WQD1|3|0000006e18ee160a111760bff2126ba1fa352ddede88c0500d6574b21d3984ee|998b82684c9cdbbf875774531a8ff85e359de44c01061dbaab0ba1e28cc3da8a|1792540980|": { nonce: 6271269, hash: "000000410bdb3de496c36fb0c0012861b471755993b9e0181b4ad1d26a679170" },
  "WQD1|4|000000410bdb3de496c36fb0c0012861b471755993b9e0181b4ad1d26a679170|da0085c2c80edc649c4dfe7b6baab05d1aa48a94f8667bfe30edf7744abcb920|1792541040|": { nonce: 1207556, hash: "000001e6a093f70763aa474dc6878bed6eb195da040f9eb49027beef23ae52bf" },
  "WQD1|5|000001e6a093f70763aa474dc6878bed6eb195da040f9eb49027beef23ae52bf|429901c20adb603092bf504997c1527d4b326db80fb043c55e00e69cb4cf1588|1792541100|": { nonce: 1310971, hash: "000002953286657c4b906e482b63c34efca11f94403ef9ba6c35371262ef7843" },
  "WQD1|6|000002953286657c4b906e482b63c34efca11f94403ef9ba6c35371262ef7843|b7b13d0e1e184ee791d83d346c88a47cfe785ae1aeccbbc494286aa61fdf2858|1792541160|": { nonce: 6026771, hash: "000001932ecf646f61e69675798b5e99f77f31b109e425dcbd71dca323a3974b" },
  "WQD1|7|000001932ecf646f61e69675798b5e99f77f31b109e425dcbd71dca323a3974b|15a5b153d783291abc9a5ccd70789a261ea7f6bd1ff9e816d8637e6bf0a2181f|1792541220|": { nonce: 2691020, hash: "000000ab59b74ed233fef44516c6afc8956ee89fa6f74ae54fdadf36cfdca222" },
  "WQD1|8|000000ab59b74ed233fef44516c6afc8956ee89fa6f74ae54fdadf36cfdca222|aa8eff39947da3628e5bd7e52fd792948be6400561a70be0403a912b86ba98ef|1792541280|": { nonce: 736002, hash: "000000047c3cab3affefe0dead48935af6cc083a51a8647b636d0de7e2dda1a7" },
  "WQD1|9|000000047c3cab3affefe0dead48935af6cc083a51a8647b636d0de7e2dda1a7|3690eb1d34349700e07b43050f80d5827bb45d8abdcdecf5b4420e3fc5b70922|1792541340|": { nonce: 1162151, hash: "0000032fbe3f89248ed2eb80b718c84a35db14e9de10d762c2833cfc1a8faec0" },
};

function powSearch(prefixAscii: string, target: string): { nonce: number; hash: string } {
  const baked = BAKED[prefixAscii];
  if (baked) return baked;
  const prefix = utf8ToBytes(prefixAscii);
  for (let nonce = 0; nonce < 2 ** 31; nonce++) {
    const d1 = sha256.create().update(prefix).update(utf8ToBytes(String(nonce))).digest();
    const hash = bytesToHex(sha256(d1));
    if (hashMeetsTarget(hash, target)) {
      console.log(`BAKE: "${prefixAscii}": { nonce: ${nonce}, hash: "${hash}" },`);
      return { nonce, hash };
    }
  }
  throw new Error("nonce space exhausted");
}

async function mineOne(): Promise<{ height: number; hash: string }> {
  const tpl = await buildTemplate(w1.address);
  // 60s block spacing: the 8-block retarget sees ideal pace and difficulty
  // stays at 1 forever - minTimestamp spacing would clamp 4x harder every
  // 8 blocks and make the long narrative ungrindable.
  const ts = Math.max(tpl.minTimestamp, GENESIS_TIMESTAMP + tpl.height * TARGET_BLOCK_TIME);
  const { nonce } = powSearch(
    `WQD1|${tpl.height}|${tpl.prevHash}|${tpl.merkleRoot}|${ts}|`,
    tpl.target,
  );
  const r = await submitBlock(tpl.templateId, ts, nonce);
  return { height: r.height, hash: r.hash };
}

let storage: MemoryStorage;
let tipHash35 = "";
let supply35 = 0;
let balance35 = 0;

beforeAll(async () => {
  storage = new MemoryStorage();
  await initChain(storage);
  for (let h = 1; h <= PRUNE_NARRATIVE_BLOCKS; h++) {
    const r = await mineOne();
    if (h === PRUNE_NARRATIVE_BLOCKS) tipHash35 = r.hash;
  }
  const i = await getInfo();
  supply35 = i.totalSupply;
  balance35 = (await getAddressOverview(w1.address)).balance;
}, 900_000);

describe("pruneConfirmedTxsBelow", () => {
  it("refuses a horizon inside the reorg window", async () => {
    // tip 35 - MAX_REORG_DEPTH 32 => deepest legal horizon is 3
    await expect(pruneConfirmedTxsBelow(4)).rejects.toThrow(ChainValidationError);
    await expect(pruneConfirmedTxsBelow(35)).rejects.toThrow(ChainValidationError);
  });

  it("prunes below the legal horizon: txs gone, headers stay, state exact", async () => {
    const removed = await pruneConfirmedTxsBelow(3);
    expect(removed).toBeGreaterThan(0);

    // historical txs are gone - those heights can no longer be SERVED
    expect(await getWireBlock(1)).toBeNull();
    expect(await getWireBlock(2)).toBeNull();
    // ...but their HEADERS remain (the chain of proof is unbroken)
    expect((await storage.blockAt(2))?.height).toBe(2);
    // heights at/above the horizon still serve in full
    expect((await getWireBlock(3))?.height).toBe(3);
    expect((await getWireBlock(PRUNE_NARRATIVE_BLOCKS))?.hash).toBe(tipHash35);

    // tip, supply and balances are untouched by the prune
    const i = await getInfo();
    expect(i.height).toBe(PRUNE_NARRATIVE_BLOCKS);
    expect(i.tipHash).toBe(tipHash35);
    expect(i.totalSupply).toBe(supply35);
    expect((await getAddressOverview(w1.address)).balance).toBe(balance35);
  });

  it("a pruned node cannot export a full chain - it says so loudly", async () => {
    await expect(exportChain()).rejects.toThrow(/pruned/);
  });

  it("the pruned node keeps mining and validating", async () => {
    const r = await mineOne(); // block 36 on pruned storage
    expect(r.height).toBe(PRUNE_NARRATIVE_BLOCKS + 1);
    const i = await getInfo();
    expect(i.height).toBe(PRUNE_NARRATIVE_BLOCKS + 1);
  }, 120_000);
});
